- [Link](https://osu.ppy.sh/beatmapsets/650607#osu/1402930)
- BPM: 195





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/V9k9uuSQ4a6jubJbNJkkODnUpu815q9bP_hR0GGoh1w" type="video/mp4"></video>