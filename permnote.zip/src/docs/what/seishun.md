- [Link](https://osu.ppy.sh/beatmapsets/1867294#osu/3842880)
- BPM: 190





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/QO_ElN_ioqmiIYIJHYQYvJXEWbHpHYilAE0TTBoi_P8" type="video/mp4"></video>