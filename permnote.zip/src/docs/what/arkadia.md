- [Link](https://osu.ppy.sh/beatmapsets/1695872#osu/3616425)
- BPM: 200






<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/2HaguVRp-cZw7jXfoLIjdpYtzwc8jvzKk0mnd83R9J8" type="video/mp4"></video>