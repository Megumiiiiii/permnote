- [Link](https://osu.ppy.sh/beatmapsets/1280204#osu/2659371)
- BPM: 200





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/HoeHIGEBOTYgRMIgaJlxmQcoonkWJrinR-IE83PUQeo" type="video/mp4"></video>