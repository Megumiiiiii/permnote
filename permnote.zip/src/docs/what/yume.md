- [Link](https://osu.ppy.sh/beatmapsets/1068768#osu/2237468)
- BPM: 176





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/76J2RtMOav-Ez3S3BnTxVYuD618a5vANhYZ1TT-EoLs" type="video/mp4"></video>