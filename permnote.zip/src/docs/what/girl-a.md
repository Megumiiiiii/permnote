- [Link](https://osu.ppy.sh/beatmapsets/2064760#osu/4318886)
- BPM: 260





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/Yko2NmADJdHuRIpLST96ieqKTspZH_PD2p7ynWFYDwE" type="video/mp4"></video>