- [Link](https://osu.ppy.sh/beatmapsets/1312079#osu/2732132)
- BPM: 185





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/bx5szOf1MxstkmvthtLiBCE7LLJZW8hIyfK4WgnWzIo" type="video/mp4"></video>