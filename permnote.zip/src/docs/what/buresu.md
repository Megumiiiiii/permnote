- [Link](https://osu.ppy.sh/beatmapsets/1889729#osu/3907767)
- BPM: 148





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/JzgvfP7BhX78zm2u46BpkwbnTD1WrLFgF_bRuXFxY_M" type="video/mp4"></video>