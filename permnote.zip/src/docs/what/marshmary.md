- [Link](https://osu.ppy.sh/beatmapsets/962088#osu/2014470)
- BPM: 182





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/g5GrUOC577qRtccBB1yIu31em8gPbvew129ArUS4X7M" type="video/mp4"></video>