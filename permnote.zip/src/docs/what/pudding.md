- [Link](https://osu.ppy.sh/beatmapsets/993369#osu/2225466)
- BPM: 150





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/ACKWqx4OoHjb2BVpGynXOAWZ7D1Me6jfWyAT62ejhbk" type="video/mp4"></video>