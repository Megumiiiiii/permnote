- [Link](https://osu.ppy.sh/beatmapsets/1556324#osu/3179304)
- BPM: 178





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/pj9G7kAR4SkuNXbeUF0YisFPKkky3b3P244Wo1jcd6U" type="video/mp4"></video>