- [Link](https://osu.ppy.sh/beatmapsets/931452#osu/1962198)
- BPM: 192





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/GnDZJ_jT3xxtBqQ4iwFTnJjZ_NGnHw1aE4HmAUXmnEw" type="video/mp4"></video>