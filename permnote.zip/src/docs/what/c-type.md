- [Link](https://osu.ppy.sh/beatmapsets/757146#osu/1620144)
- BPM: 149.3





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/xTT-Tt7EmSdU_ALYDZSZqZqvk26KbA4rD7Q_gR5pIvA" type="video/mp4"></video>