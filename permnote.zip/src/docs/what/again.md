- [Link](https://osu.ppy.sh/beatmapsets/801074#osu/1681634)
- BPM: 150





<video width="100%" height="auto" controls autoplay loop src="https://arweave.net/Sdgker22LW85KWozIzONFUzkHjaF4oW7ijIx9sXrAcQ" type="video/mp4"></video>