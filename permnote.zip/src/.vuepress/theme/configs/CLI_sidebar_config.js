module.exports = [
    {
      title: 'Intro',
      path: '/docs/cli/intro'
    },
    {
      title: 'Getting Started',
      path: '/docs/cli/getting-started',
    },
    {
      title: 'Using the CLI',
      path: '/docs/cli/using-the-cli'
    },
    {
      title: 'All Commands',
      path: '/docs/cli/all-commands'
    },
    {
      title: 'Getting Help',
      path: '/docs/cli/getting-help'
    }
  ]