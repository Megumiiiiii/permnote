module.exports = [
    {
        text: 'CLI',
        link: '/docs/cli/intro'
    },
    {
        text: 'SDK',
        link: '/docs/core-sdk'
    },
    {
        text: 'Price Calculator',
        link: '/docs/price-calculator'
    }
]